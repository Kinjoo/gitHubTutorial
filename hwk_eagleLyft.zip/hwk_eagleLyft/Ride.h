#include <string>

using namespace std;

class Ride {
    public:

    private:

};