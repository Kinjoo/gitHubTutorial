#include "Driver.h"


#include <iostream>
#include <string>

using namespace std;

void Menu() {
    cout << "Welcome to EagleLyft\nAre you a Driver or Passenger?\n 1. Driver\n 2. Passenger" << endl;

}

int main() {
    int choice = -1;
    while (choice != 0) {
        Menu();
        cin >> choice;
        cin.ignore();

    switch (choice) {
        case 1:     //Navigate to driver menu
        cout << "You are now in the Driver menu" << endl;
        break;
        case 2:     //Navigate to passenger menu
        cout << "You are now in the Passenger menu" << endl;
        break;
        default: 
        cout << "Invalid, Please try again." << endl;
    }    

    }

}