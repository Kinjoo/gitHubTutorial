#include <string>

using namespace std;

class Passenger {
    public: 
        Passenger();
        Passenger(int id, string name);

        void setID();
        void setName();

        int getId();
        string getName();

    private:
        int id;
        string name;
};

