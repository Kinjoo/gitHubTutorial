#include <string>

using namespace std;

class Driver {
    public:
        Driver();
        Driver(int id, int rating, string name);

        void setID(int id);
        void setRating(int rating);
        void setName(string name);

        int getID();
        int getRating();
        string getName();

    private:
        int id;
        int rating;
        string name;
};
