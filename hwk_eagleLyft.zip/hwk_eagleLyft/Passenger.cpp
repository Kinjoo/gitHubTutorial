#include <iostream>
#include "Passenger.h"
using namespace std;

Passenger::Passenger() {

}
Passenger::Passenger(int id, string name) {

}
void Passenger::setID() {

}
void Passenger::setName() {

}
int Passenger::getId() {

}
string Passenger::getName() {

}
