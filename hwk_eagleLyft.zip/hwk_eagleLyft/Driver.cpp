#include <iostream> 

#include "Driver.h"

Driver::Driver() {

}
Driver::Driver(int id, int rating, string name) {
    
}
void Driver::setID(int id) {
    
}
void Driver::setRating(int rating) {
    
}
void Driver::setName(string name) {
    
}
int Driver::getID() {
    return id;
}
int Driver::getRating() {
    return rating;
}
string Driver::getName() {
    return name;
}